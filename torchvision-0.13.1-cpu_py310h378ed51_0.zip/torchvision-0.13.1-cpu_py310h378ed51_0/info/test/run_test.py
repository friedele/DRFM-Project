print("import: 'torchvision'")
import torchvision

print("import: 'torchvision.datasets'")
import torchvision.datasets

print("import: 'torchvision.transforms'")
import torchvision.transforms

print("import: 'torchvision.models'")
import torchvision.models

print("import: 'torchvision.utils'")
import torchvision.utils

